# QuantumShield Sample Repository

This is a bundled sample repository for QuantumShield demonstration purposes.

## Purpose
Provides repeatable, safe test input for the QuantumShield scanner and risk engine.

## Expected Detections

| File | Algorithm | Expected Risk |
|---|---|---|
| python_app/auth/token_signer.py | RSA | HIGH — digital signature |
| python_app/crypto/session_key.py | RSA | HIGH — key establishment |
| python_app/storage/db_encrypt.py | AES-128 | MODERATE |
| python_app/storage/vault.py | AES-256 | LOWER |
| python_app/utils/checksum.py | SHA-256 | LOWER |
| java_app/src/auth/Signer.java | ECDSA | HIGH — digital signature |
| java_app/src/crypto/KeyExchange.java | RSA | HIGH — key establishment |
| c_app/network/handshake.c | ECDH | HIGH — key agreement |
| python_app/utils/string_utils.py | — | None (negative case) |

## Disclaimer
No real credentials or private keys are included.
All cryptographic patterns are illustrative; no code in this sample is meant to be executed.
