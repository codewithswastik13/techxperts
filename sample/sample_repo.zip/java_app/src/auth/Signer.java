/**
 * Digital signature using ECDSA with P-256 curve.
 * Expected detections: ECDSA
 * Expected risk: HIGH — elliptic curve discrete log broken by Shor's algorithm
 * Recommendation: migrate to ML-DSA (NIST FIPS 204)
 */
import java.security.*;
import java.security.spec.ECGenParameterSpec;

public class Signer {

    private PrivateKey privateKey;
    private PublicKey publicKey;

    public Signer() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("EC");
        kpg.initialize(new ECGenParameterSpec("secp256r1"));
        KeyPair kp = kpg.generateKeyPair();
        this.privateKey = kp.getPrivate();
        this.publicKey = kp.getPublic();
    }

    public byte[] sign(byte[] data) throws Exception {
        Signature sig = Signature.getInstance("SHA256withECDSA");
        sig.initSign(privateKey);
        sig.update(data);
        return sig.sign();
    }

    public boolean verify(byte[] data, byte[] signature) throws Exception {
        Signature sig = Signature.getInstance("SHA256withECDSA");
        sig.initVerify(publicKey);
        sig.update(data);
        return sig.verify(signature);
    }
}
