/**
 * RSA-based session key establishment.
 * Expected detections: RSA
 * Expected risk: HIGH — RSA factorization broken by Shor's algorithm
 * Recommendation: migrate to ML-KEM (NIST FIPS 203)
 */
import javax.crypto.Cipher;
import java.security.*;

public class KeyExchange {

    public byte[] wrapKey(byte[] sessionKey, PublicKey recipientKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        cipher.init(Cipher.ENCRYPT_MODE, recipientKey);
        return cipher.doFinal(sessionKey);
    }

    public byte[] unwrapKey(byte[] wrappedKey, PrivateKey myKey) throws Exception {
        Cipher cipher = Cipher.getInstance("RSA/ECB/OAEPWithSHA-256AndMGF1Padding");
        cipher.init(Cipher.DECRYPT_MODE, myKey);
        return cipher.doFinal(wrappedKey);
    }

    public KeyPair generateRsaKeyPair() throws Exception {
        KeyPairGenerator kpg = KeyPairGenerator.getInstance("RSA");
        kpg.initialize(2048);
        return kpg.generateKeyPair();
    }
}
