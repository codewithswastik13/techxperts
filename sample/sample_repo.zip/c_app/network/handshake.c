/*
 * TLS-like handshake using ECDH for key agreement.
 * Expected detections: ECDH
 * Expected risk: HIGH — ECDH vulnerable to Shor's algorithm CRQC attack
 * Recommendation: hybrid X25519+ML-KEM during transition
 */
#include <openssl/evp.h>
#include <openssl/ec.h>
#include <string.h>

int ecdh_derive_shared_secret(EVP_PKEY *local_key, EVP_PKEY *peer_key,
                               unsigned char *secret, size_t *secret_len) {
    EVP_PKEY_CTX *ctx = EVP_PKEY_CTX_new(local_key, NULL);
    if (!ctx) return -1;

    if (EVP_PKEY_derive_init(ctx) <= 0) goto cleanup;
    if (EVP_PKEY_derive_set_peer(ctx, peer_key) <= 0) goto cleanup;
    if (EVP_PKEY_derive(ctx, secret, secret_len) <= 0) goto cleanup;

    EVP_PKEY_CTX_free(ctx);
    return 0;

cleanup:
    EVP_PKEY_CTX_free(ctx);
    return -1;
}
