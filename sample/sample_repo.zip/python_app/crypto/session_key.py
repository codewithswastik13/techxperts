"""
Symmetric session key exchange using RSA OAEP.
Expected detections: RSA (key establishment purpose)
Expected risk: HIGH — 'Store Now Decrypt Later' threat applies
"""
from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP


def wrap_session_key(session_key: bytes, recipient_public_key_pem: bytes) -> bytes:
    """Encrypt a session key with the recipient's RSA public key."""
    recipient_key = RSA.import_key(recipient_public_key_pem)
    cipher = PKCS1_OAEP.new(recipient_key)
    return cipher.encrypt(session_key)


def unwrap_session_key(wrapped_key: bytes, private_key_pem: bytes) -> bytes:
    """Decrypt a wrapped session key using our RSA private key."""
    key = RSA.import_key(private_key_pem)
    cipher = PKCS1_OAEP.new(key)
    return cipher.decrypt(wrapped_key)
