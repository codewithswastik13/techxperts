"""
JWT-like token signing using RSA.
Expected detections: RSA (digital signature purpose)
Expected risk: HIGH — quantum-vulnerable public-key operation
"""
from Crypto.PublicKey import RSA
from Crypto.Signature import pss
from Crypto.Hash import SHA256


class TokenSigner:
    def __init__(self):
        self.private_key = RSA.generate(2048)
        self.public_key = self.private_key.publickey()

    def sign_token(self, payload: bytes) -> bytes:
        h = SHA256.new(payload)
        signer = pss.new(self.private_key)
        return signer.sign(h)

    def verify_token(self, payload: bytes, signature: bytes) -> bool:
        h = SHA256.new(payload)
        verifier = pss.new(self.public_key)
        try:
            verifier.verify(h, signature)
            return True
        except (ValueError, TypeError):
            return False
