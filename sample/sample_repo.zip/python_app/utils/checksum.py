"""
File integrity verification using SHA-256.
Expected detections: SHA-256
Expected risk: LOWER — hash function, not a public-key or symmetric cipher
Grover provides quadratic speedup but hash functions are not quantum-broken.
"""
import hashlib


def compute_checksum(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def verify_checksum(data: bytes, expected: str) -> bool:
    return compute_checksum(data) == expected
