"""
String utility functions — no cryptographic operations.
Expected detections: NONE
This file is a negative test case.
"""

def slugify(text: str) -> str:
    """Convert a string to a URL-safe slug."""
    return text.lower().replace(" ", "-").strip("-")


def truncate(text: str, max_length: int = 100) -> str:
    if len(text) <= max_length:
        return text
    return text[:max_length - 3] + "..."
