"""
High-security secret vault using AES-256-GCM.
Expected detections: AES-256
Expected risk: LOWER — retains ~128-bit quantum security margin
No PQC replacement needed; mode and IV hygiene still required.
"""
from Crypto.Cipher import AES
import os

KEY_SIZE = 32  # 32 bytes = AES-256


def encrypt_secret(plaintext: bytes, master_key: bytes) -> dict:
    """Encrypt a secret with AES-256-GCM. Returns nonce, tag, and ciphertext."""
    assert len(master_key) == KEY_SIZE
    nonce = os.urandom(16)
    cipher = AES.new(master_key, AES.MODE_GCM, nonce=nonce)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext)
    return {"nonce": nonce, "tag": tag, "ciphertext": ciphertext}
