"""
Database field encryption using AES-128-CBC.
Expected detections: AES-128
Expected risk: MODERATE — Grover halves effective security to ~64 bits
Recommendation: upgrade key length to AES-256
"""
from Crypto.Cipher import AES
import os

# 16-byte key = AES-128
KEY_SIZE = 16


def encrypt_field(data: bytes, key: bytes) -> tuple[bytes, bytes]:
    """Encrypt a database field. Returns (ciphertext, iv)."""
    assert len(key) == KEY_SIZE, "AES-128 requires a 16-byte key"
    iv = os.urandom(16)
    cipher = AES.new(key, AES.MODE_CBC, iv)
    padded = _pad(data)
    return cipher.encrypt(padded), iv


def _pad(data: bytes) -> bytes:
    pad_len = 16 - (len(data) % 16)
    return data + bytes([pad_len] * pad_len)
